<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$manifest = array();

$manifest['id'] = 'dotdigital';

$manifest['supported_extensions'] = array(
	'events' => array(),
	'social' => array(),
	'page-builder' => array(),
	'slider'       => array(),
	'breadcrumbs'  => array(),
	'megamenu'     => array(),
	'sidebars'     => array(),
	'portfolio'    => array(),
	'backups'      => array(),
);
