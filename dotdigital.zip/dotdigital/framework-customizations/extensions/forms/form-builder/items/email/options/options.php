<?php if (!defined('FW')) die('Forbidden');

$options = array(
	'icon' => array(
		'type' => 'icon',
		'label' => esc_html__( 'Icon', 'dotdigital' ),
		'set'   => 'rt-icons-2',
	)
);