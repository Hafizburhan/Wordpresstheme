<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$options = array(
	'mouse_button_link'      => array(
		'type'  => 'text',
		'value'   => '',
		'label' => esc_html__( 'Mouse button link', 'dotdigital' ),
	),
);