<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Images carousel', 'dotdigital' ),
		'description' => esc_html__( 'Show images carousel with optional links', 'dotdigital' ),
		'tab'         => esc_html__( 'Media Elements', 'dotdigital' ),
	)
);