<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg['page_builder'] = array(
	'title'       => esc_html__( 'Media item (vertical)', 'dotdigital' ),
	'description' => esc_html__( 'Add an image with bottom text block', 'dotdigital' ),
	'tab'         => esc_html__( 'Content Elements', 'dotdigital' )
);