<?php if ( ! defined( 'FW' ) ) {
	die( 'Forbidden' );
}

$cfg = array(
	'page_builder' => array(
		'title'       => esc_html__( 'Icons in list', 'dotdigital' ),
		'description' => esc_html__( 'Several icons in bordered list', 'dotdigital' ),
		'tab'         => esc_html__( 'Content Elements', 'dotdigital' ),
	)
);