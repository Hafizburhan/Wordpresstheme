<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

?>
<div class="search-icon">
	<a href="#header-search" title="<?php esc_attr_e( 'Search', 'neeon');?>">
	    <i class="fas fa-search"></i>
	</a>
</div>

