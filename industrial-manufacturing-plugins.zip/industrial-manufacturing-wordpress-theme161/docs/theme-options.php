<?php
/* Include all files from elements folder */
$dir = 'theme-options';
if ($handle = opendir($dir)) {
    $arr = array();
    while (false !== ($entry = readdir($handle))) {
        $explode_entry = explode('.', $entry);
        if($explode_entry[1]=='html') {
            include_once $dir.'/'.$entry;
        }
    }
    closedir($handle);
}