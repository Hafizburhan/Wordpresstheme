<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

?>
<div class="user-icon-area">
	<a href="<?php echo esc_url( wp_login_url() ); ?>"><i class="far fa-user"></i></a>
</div>