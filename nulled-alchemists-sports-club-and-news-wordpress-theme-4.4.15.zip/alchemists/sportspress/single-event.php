<?php
/**
 * The template for displaying Event
 *
 * @author    Dan Fisher
 * @package   Alchemists
 * @since     3.0.10
 * @version   3.0.10
 */

get_header();

get_template_part( 'sportspress/sp-template-parts/sp-post' );

get_footer();
