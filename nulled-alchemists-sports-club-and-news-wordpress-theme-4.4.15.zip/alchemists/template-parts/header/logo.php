<?php
/**
 * Template part for Header Logo.
 *
 * @author    Dan Fisher
 * @package   Alchemists
 * @since     4.0.0
 * @version   4.0.2
 */

$logo_standard        = isset( $alchemists_data['alchemists__opt-logo-standard']['url'] ) ? esc_html( $alchemists_data['alchemists__opt-logo-standard']['url'] ) : '';
$logo_retina          = isset( $alchemists_data['alchemists__opt-logo-retina']['url'] ) ? esc_html( $alchemists_data['alchemists__opt-logo-retina']['url'] ) : '';

$default_logo_path = '';
if ( alchemists_sp_preset('soccer') ) {
	$default_logo_path = 'soccer/';
} elseif ( alchemists_sp_preset('football') ) {
	$default_logo_path = 'football/';
} elseif ( alchemists_sp_preset('esports') ) {
	$default_logo_path = 'esports/';
}
?>

<!-- Header Logo -->
<div class="header-logo">
	<a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home">
		<?php if ( !empty( $logo_standard ) ) : ?>
			<img src="<?php echo esc_url( $logo_standard ); ?>" <?php if ( !empty( $logo_retina ) ) { ?> srcset="<?php echo esc_url( $logo_retina ); ?> 2x" <?php } ?> class="header-logo__img" alt="<?php bloginfo('name'); ?>">
		<?php else : ?>
			<img src="<?php echo get_template_directory_uri(); ?>/assets/images/<?php echo $default_logo_path; ?>logo.png" class="header-logo__img" srcset="<?php echo get_template_directory_uri(); ?>/assets/images/<?php echo $default_logo_path; ?>logo@2x.png 2x" alt="<?php esc_attr( bloginfo('name') ); ?>">
		<?php endif; ?>
	</a>
</div>
<!-- Header Logo / End -->
