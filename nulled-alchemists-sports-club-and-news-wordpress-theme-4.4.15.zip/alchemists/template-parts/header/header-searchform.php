<?php
/**
 * Template part for Header Secondary section.
 *
 * @author    Dan Fisher
 * @package   Alchemists
 * @since     1.0.2
 * @version   4.4.8
 */

// Header Search Form
add_filter( 'get_search_form', 'alchemists_header_search_form' );
get_search_form();
remove_filter( 'get_search_form', 'alchemists_header_search_form' );
