<?php
/*
 * Shortcodes moved to plugin
 */