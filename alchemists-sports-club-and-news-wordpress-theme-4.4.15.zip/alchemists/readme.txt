Contributors: Dan Fisher

Tested up to: 5.9.2

#### Support Policy

##### Item support includes:

1. Availability of the author to answer questions
2. Answering technical questions about item’s features
3. Assistance with reported bugs and issues
4. Help with included 3rd party assets

##### However, item support does not include:

1. Customization services
2. Installation services

If you need help with customization, you will need to find and hire a developer capable of making the changes.

[Go to item support](https://danfisher.ticksy.com)

#### Changelog:

= 4.4.15 =
* [tweak] Theme Options - added option to set relative values for Player Stats progress bars (Soccer, Football)
* [tweak] ALC: Player Game-by-Game Stats - added option to display events for multiple Current Teams
* [tweak] WPBakery Page Builder - added Charts and Progress Bars default elements
* [tweak] Theme Options - added Copyright Typography
* [tweak] Theme Options - added option to customize typography in tables separately
* [update] Slider Revolution 6.5.19
* [update] ACF 5.12.1

= 4.4.14 =
* [tweak] Added option to display Pushy Panel on mobile devices
* [tweak] ALC: Newslog - moved styles to the basic category (can be used when SportsPress is disabled)
* [fix] Small tweak and fixes

= 4.4.13 =
* [tweak] WooCommerce 6.1 compatibility
* [tweak] Tested up to WordPress 5.9
* [update] Slider Revolution 6.5.15

= 4.4.12 =
* [fix] Whatsapp share button doesn't work on desktop
* [update] Slider Revolution 6.5.14
* [update] Alchemists Advanced Posts 2.1.2
* [update] WPBakery Page Builder 6.8.0

= 4.4.11 =
* [tweak] SportsPress 2.7.13 compatibility
* [tweak] Jumbotron - Set Title color set as headings color
* [update] Slider Revolution 6.5.11
* [update] ACF 5.11.4

= 4.4.10 =
* [tweak] Changed location for SportsPress plugin

= 4.4.9 =
* [tweak] WooCommerce 5.9 compatibility has been checked
* [fix] WooCommerce Product Reviews throw an error in some rare cases
* [fix] Single Player - Average Circular Bars throw errors in some rare cases
* [fix] Goals sorting throw error in some rare cases (Soccer)
* [fix] Team - If Team is set as Protected then some parts are still visible
* [update] Slider Revolution 6.5.9

= 4.4.8 =
* [tweak] WooCommerce 5.6.0 compatibility
* [tweak] Main Search Form and Header Search Form tweaked to be compatible with third-party plugins, e.g. Polylang
* [tweak] Player Header Full Width layout - display social links
* [update] Slider Revolution 6.5.8
* [update] Translation files
* [update] ACF 5.10.2

= 4.4.7 =
* [tweak] ALC: Post Loop - added an anchor to pagination links if ID attribute is set
* [tweak] Theme Options - removed 'transparent' color for fields used to build color schemes to prevent issues on SCSS compiling
* [tweak] Translation files updated
* [update] Slider Revolution 6.5.7

= 4.4.6 =
* [new] French traslation added (thanks to Pierre Cailly)
* [tweak] Theme Options - added option to customize texts of Site Name and Tagline in the Footer
* [tweak] Removed block support from Widget areas
* [tweak] Checked with WordPress 5.8
* [fix] Theme Options - fixed Redux styling issues
* [fix] Events Archive - events are not displayed on Day Archive if Teams option is disabled
* [fix] ALC: Post Grid Slider - layout is broken if posts number is not multiple of 3
* [update] Slider Revolution 6.5.5
* [update] ACF 5.9.9
* [update] WPBakery Page Builder 6.7.0

= 4.4.5 =
* [fix] eSports - Kills and K/D/A ratio icons are not displayed
* [fix] ALC: Event Scoreboard + Event Page - added a space between League and Season words
* [fix] chartjs - Title displayed in chart tooltips in Safari (ALC: Games History, ALC: Team Points History, Single Player Radar Chart, etc.)
* [fix] Friendly events filter doesn't work correctly for Event Blocks layout
* [update] Slider Revolution 6.5.2

= 4.4.4 =
* [tweak] Name or Surname for players with one name (or surname) formatted incorrectly
* [fix] Comment section background color is not reflecting on color customization
* [fix] Custom Nav Paddings don't work
* [fix] Child Theme - set child theme's version for the child theme stylesheet
* [fix] Player Boxed - layout is broken if name is too long
* [fix] Event Match Result - Awards > Star Number displayed incorrectly
* [tweak] WooCommerce 5.2 compatibility
* [update] ACF 5.9.6
* [update] Slider Revolution 6.4.11
* [update] DF Social Count 1.3.1

= 4.4.3 =
* [new] Theme Options: Footer Copyright - added option to display only Text
* [new] Theme Options: Hero Unit Static - added typography options
* [tweak] Post Filter - "Order By" options wrapped with filter to be able to change them in a child theme
* [tweak] Theme Options: Tertiary Nav - added option to set 0px height
* [tweak] Theme Options: Typography - added global option to change font-style and font-weight for accent font
* [tweak] Sponsors - decreased minimum value for the Sponsors Carousel autospeed option (1s)
* [tweak] Ajax Loader tweaked for Contact Form 7 5.4+
* [tweak] Event Logos - header elements are not centered if side element missed (eSports)
* [tweak] Added posibility to customize placeholder images via child theme
* [tweak] Removed some jQuery deprecations
* [tweak] WPML - better compatibility
* [tweak] Translation files updated
* [update] Alchemists SCSS Compiler 4.4.1
* [update] Slider Revolution 6.4.3
* [update] WPBakery Page Builder 6.6.0
* [update] Alchemists WooCommerce Grid / List toggle 1.1.5
* [update] Alchemists Advanced Posts 2.1.1
* [update] ACF 5.9.5
* [fix] Team Roster - fixed some incorrect colors (eSports)
* [fix] Team Roster - "Medic" icon is not displayed (eSports)
* [fix] Typography - italic fonts are not customizable for different headings (eSports)
* [fix] ALC: Text Ticker - secondary custom color is not changing (eSports)
* [fix] ALC: Text Ticker - category labels are not vertically aligned
* [fix] ALC: Event Results - fixed incorrect colors for expand button
* [fix] Twitch - "Live" label had an incorrect text color in some cases
* [fix] Event Blocks - broken layout might appear if Team Names are too long
* [fix] Shop: Product Grid - incorrect number of columns displayed in Grid view
* [fix] Shop: View icon - incorrect color
* [fix] Shop: View Toggle - incorrect color (American Football)
* [fix] ALC: Post Loop - fixed bug with non-working pagination on Home page
* [fix] ALC: Post Loop - 2 cols displayed if "Card 3 cols" layout is set
* [tweak] Small tweaks and fixes

= 4.4.2 =
* [tweak] ALC: Albums - added option to select specific albums
* [tweak] Theme Options: Player Header - added option to select Statistics
* [tweak] Replaced texts for SportsPress > Settings > Matches > Teams > Layout (Default and Extended)
* [update] Slider Revolution 6.3.5
* [update] ACF 5.9.4
* [fix] Player Blocks - Birthday displayed even if the option is disabled
* [fix] SportsPress Pro Tournament brackets - incorrect color for brackets
* [fix] ALC: Text Ticker - incorrect work on RTL sites
* [fix] ALC: Post Grid - Layout 1-2 - links opened in an iframe

= 4.4.1 =
* [tweak] Preloader - remove border radius from image-based preloaders
* [fix] ALC: Player Game-by-game - error appears if Past Team is empty
* [fix] Single Player - broken layout (incorrect initialization)
* [fix] Theme Options - false positive for HEX color validations in some rare cases
* [fix] Event Scoreboard - outputs old events (SportsPress Pro)
* [fix] Hero Unit Post Slider - view icon displayed twice
* [tweak] Small JS tweaks

= 4.4.0 =
* [new] Basketball and Soccer dark color versions
* [new] Instagram widget on Home 2 (eSports)
* [new] DF Social Count: added VK button
* [new] Added "Canvas" template which doesn't include Header, Footer, and Sidebar
* [new] Theme Options - added option to customize Header Mobile height
* [tweak] ALC: Post Loop - if 2 or 3 cols layout is selected make post height equal
* [tweak] Added 'alchemists_after_post_featured_img' action hook to post images (dev)
* [tweak] Theme Options - added Track color option
* [tweak] Changed Circular Bars static track color to dynamic (customizable)
* [tweak] DF Social Count: Removed Google+ counter
* [tweak] DF Social Count: Updated Instagram counter
* [tweak] Theme Options: Top Bar Social Links - added option to customize colors (regular, hover) and opacity
* [tweak] Widgets Recent Posts, Top Posts - added option to display posts by for a time period
* [tweak] Player: small tweaks for player photo on mobile (eSports)
* [tweak] Player Roster: Carousel + Thumbs - added navigation arrows on mobile (eSports)
* [tweak] Player Roster: Carousel + Thumbs - make carousel nav centered (visible if less 6 players displayed)
* [tweak] Player Roster: Carousel + Thumbs - added navigation arrows to carousel if more than 6 players are visible
* [tweak] Widget Results - replaced Description with Title
* [tweak] Post Views - reworked with AJAX
* [tweak] SVG Icons - removed inline fills and strokes
* [tweak] Instagram Feed 2.5 compatibility
* [tweak] ALC: Team Leaders - added option to change order (ASC, DESC)
* [tweak] ALC: Team Leaders - added additional parameter (Played Games) to sort players
* [tweak] ALC: Team Leaders - added option to reverse circular bars
* [tweak] Events List - added video icon to buttons for events with videos
* [tweak] Theme Options - added option to set the fixed Header Mobile
* [tweak] Sponsors - layout improvements enhancement (option to set it in carousel view)
* [tweak] JS tweaks and deprecations
* [tweak] Theme Options - add option to customize Progress Background Color
* [tweak] Twitch - replace static streamers background with streamers channel background (if set)
* [tweak] ALC: Player Game-by-Game - incorrect output if player changed the team
* [update] Bootstrap 4.5.3
* [update] FontAwesome 5.15.1
* [update] Alchemists Advanced Posts 2.1.0
* [update] DF Social Count 1.3.0
* [update] Alchemists SCSS Compiler 4.4.0
* [update] Slider Revolution 6.3.3
* [update] WPBakery Page Builder 6.5.0
* [update] Demo import files
* [update] SportsPress 2.7.5
* [fix] SportsPress Pro: Box Score - removed code output
* [fix] Events - the issue when "Recap" is displayed for unpublished events
* [fix] Sponsors - issue when the top border is not visible
* [fix] Header Tertiary Nav Dropdown - incorrect z-index
* [fix] ALC: Event Results - empty values cause to error

= 4.3.3 =
* [tweak] Social Links - removed translation function for Social Links
* [tweak] Improved layout for Tablets ('order-md-*' replaced with 'order-lg-*')
* [tweak] Team Roster - made Roster List fullwidth if Featured Player is not selected
* [tweak] WC Header Shopping Cart - removed unnecessary escaping
* [tweak] Event Box Score - applied Team Colors to progress bars (fro SportsPress Pro)
* [tweak] ALC: Player Stats - added option to customize background image
* [fix] Social Links - hover color remains default after color scheme customization
* [fix] Featured Player - Performance icons are not displayed
* [fix] Event Logos Block - added check for empty values (eSports)
* [fix] Event List - added check for an empty venue array
* [fix] Player Performances - icons were displayed for equations
* [fix] Event Scoreboard - Progress Bars reworked with Progress Tables (long label width issue)
* [fix] ALC Scoreboard - Progress Bars rework with Progress Tables (long label width issue)
* [update] Alchemists SCSS Compiler 4.3.1
* [update] Alchemists Advanced Posts 2.0.8
* [update] ACF 5.9.3

= 4.3.2 =
* [tweak] WooCommerce 4.6 compatibility
* [tweak] Single Player Header - don't show 'current team' and 'last team' if empty
* [fix] Post Navigation 2 - Post Author info remains visible even if disabled for next post
* [fix] ALC: Teams Stats, ALC: Box Info - threw error when a new inner element is added
* [fix] ALC: Player Stats Graph Log - timed stats threw errors on generating graph
* [fix] ALC: Event Results - error appears on custom progress bars (eSports)

= 4.3.1 =
* [update] WPBakery Page Builder 6.4.1
* [update] Slider Revolution 6.2.23
* [update] ACF 5.9.1
* [tweak] Small tweaks and fixes

= 4.3.0 =
* [tweak] SportsPress 2.7.4 compatibility
* [tweak] WooCommerce 4.4.0 compatibility
* [tweak] ALC: Post Loop (List - Card Tile Small) - added stretched link
* [tweak] Event goals - goals ordered by time
* [tweak] Added 'font-display' swap to default Google Fonts
* [tweak] ALC: Post Slider - slide images are stretching now
* [fix] SP Player details displayed squashed on mobile devices in some cases
* [fix] Team Roster - added option to change background image (Soccer)
* [fix] Player Cards - background were not reflecting on theme color scheme changes (Soccer)
* [update] Alchemists SCSS Compiler 4.3.0
* [update] Slider Revolution 6.2.22
* [update] ACF 5.9.0
* [update] WPBakery Page Builder 6.3.0
* [fix] Small tweaks and fixes

= 4.2.11 =
* [fix] Small tweaks and fixes

= 4.2.10 =
* [tweak] Event List - improved metadata markup
* [tweak] Single Event - improved metadata markup
* [tweak] Widget Areas - added 2 additional widget areas for Megamenu
* [update] Slider Revolution 6.2.18
* [update] ACF 5.8.13
* [update] Translation files
* [fix] Small tweaks and fixes

= 4.2.9 =
* [tweak] Make alerts styling compatibility with Contact Form 7 v5.2+
* [tweak] ALC: Post Grid - added hover effect on posts
* [tweak] Posts - change heart icon color for liked posts
* [tweak] WooCommerce 4.3.1 compatibility
* [fix] ALC: Post Loop - pagination doesn't work if 'offset' parameter is set
* [fix] ALC: Post Loop - excerpt and meta colors are incorrect on light themes (if body font is too dark)
* [fix] Hero Unit - Posts Slider - post data color is incorrect on light theme (if body font is dark)
* [fix] Contact Form 7 ajax loader icon is broken
* [fix] Small tweaks and fixes
* [update] Slider Revolution 6.2.17
* [update] Translation files

= 4.2.8 =
* [tweak] Theme Options - add option to customize dropdown menu items background color on hover
* [tweak] SP Event Blocks - display event status if not "OK"
* [tweak] News Filter doesn't work if Remove Uppercase Accents plugin installed
* [tweak] Events aren't displayed in [event_list] shortcode (eSports)
* [tweak] Theme Options - added Custom Text fields for Primary and Secondary emails
* [tweak] Hero Unit - Posts Slider - added option to display 4 posts in slider navigation
* [tweak] ALC: Post Loop - added Cards 3 cols layout
* [tweak] ALC: Album - added "Image Top + Thumbs + Title Bottom" layout option
* [tweak] PHP 7.3 compatibility
* [tweak] ALC: Jumbotron - added option to add link
* [tweak] Twitch: Embedded player didn’t play the video and (Twitch for WordPress 3.0.1 compatibility)
* [fix] Team Gallery - icon is not visible if Team Gallery Layout is set to Image Top + Thumbs + Title Bottom for Basketball/Soccer
* [fix] Hero Unit - Post Views, Likes, Comments remain visible even if were disabled in Theme Options
* [fix] Jumbotron - fixed issue when title color isn't reflecting on color changes
* [fix] Hero Unit Posts Slider - fixed compatibility issue with Massive Addons for WPBakery Page Builder
* [update] Translation files
* [update] Alchemists SCSS Compiler 4.2.3
* [update] ACF 5.8.12
* [update] Slider Revolution 6.2.15

= 4.2.7 =
* [fix] Small tweaks and fixes

= 4.2.6 =
* [tweak] ALC: Description List - added ability to add links for the items
* [tweak] Demo Data - updated options to make "Team Overview" and "Player Overview" subpages active by default
* [fix] Player Header - Social Links are displayed even if Player Header Full width layout is selected
* [fix] Color - Select2 dropdown doesn't filled with a solid color (eSports)
* [fix] "View Button" string is not translatable
* [update] Update translation files
* [update] Alchemists SCSS Compiler 4.2.2
* [update] Slider Revolution 6.2.9
* [update] Alchemists Color Filters for WooCommerce 1.0.4
* [update] Alchemists WooCommerce Grid / List toggle 1.1.4

= 4.2.5 =
* [tweak] ALC: Featured Player - added customisation option for progress and circular bars
* [tweak] Video - added support with "youtu.be" links opened in popup for Event widgets (eSports)
* [fix] ALC - Recent Posts and ALC - Top Posts widgets displayed posts in a wrong order for popular by view option
* [fix] Player - incorrect Role/Character position for Player Boxed Header on Chrome, Firefox
* [fix] Player - Social Icon for unknown networks is broken (eSports)
* [fix] Player - Overview subpage doesn't work in some cases
* [fix] Player - Custom social icon position in IE11 (eSports)
* [fix] Player - Player Header overlay is not transparent on IE11 (eSports)
* [fix] Team - Overview subpage doesn't work in some cases
* [fix] ALC: Featured Player - "Featured Player" ribbon is not visible (American Football)
* [update] Translation files
* [update] Alchemists Advanced Posts 2.0.7
* [update] Slider Revolution 6.2.8
* [update] ACF 5.8.11

= 4.2.4 =
* [new] Sponsors - add option to display Sponsors after the Header
* [tweak] Matchday - small styling tweaks for matchday displayed on Events widgets (Soccer, Football)
* [tweak] WooCommerce 4.1 compatibility
* [tweak] WC - added theme version parameter to woocommerce-$sport.css files to prevent caching if the file was updated
* [fix] ALC - Recent Posts widget - incorrect posts order for popular by comments posts
* [update] Slider Revolution 6.2.6
* [update] Alchemists Advanced Posts 2.0.6

= 4.2.3 =
* [tweak] Team Subpages - added option to set any Team subpage as default
* [tweak] Player Subpages - added option to set any Player subpage as default
* [tweak] Blog Filter - assigned link colors to Headings Color
* [tweak] Theme Options - added options to change Post Label text colors
* [tweak] Event Logos Blocks - removed statistics output for non-pubslished events (eSports)
* [tweak] Event - improve displaying results for Event Logos Blocks and ALC: Event Scoreboard (eSports)
* [tweak] Social Counters - added support for the new Twitch Helix API
* [tweak] Player Blocks - improved styling for Heading in Grouped Player Lists
* [tweak] Player Blocks - display birthday
* [tweak] Staff Blocks - display nationality after Age and Birthday
* [tweak] WC Checkout - coupon layout tweaks
* [tweak] WC My Account > Orders > Details - improved layout and styling
* [tweak] Theme Options - added option to enabled/disable Post Author
* [fix] Blog - Custom colors of Post Category Group 6 and greater don't work (eSports)
* [fix] WC Register - broken layout for 'remember me' and 'forgot password'
* [fix] WC Cart coupon - submit button on mobile devices
* [update] DF Social Count 1.2.1
* [update] Alchemists Advanced Posts 2.0.5

= 4.2.2 =
* [tweak] ALC: Staff Bio Card - display all jobs assigned to the Staff Member
* [tweak] Theme Options - add option to customize Page Heading - Title overlay opacity
* [tweak] Header Layout 4 - menu doesn't have a full width in some cases
* [tweak] Single Post Images weren't displayed for some singlpe post layouts if shared with Twitter
* [update] Alchemists Advanced Posts 2.0.4
* [update] WPBakery Page Builder 6.2.0
* [update] Translation files updated
* [fix] Pushy Panel Logo - custom size applied incorrectly
* [fix] Event Results - the event result values weren't order by 'menu_order' parameter. Affected: single event for Basketball and Football, event scoreboard (basketball, football), ALC: Event Result widget
* [fix] Twitter sharing functionality

= 4.2.1 =
* [new] Added Secondary Navigation
* [new] Post - add option to change Post Title tag
* [tweak] SportsPress 2.7.1 compatibility
* [tweak] ALC: Featured Post - added option to display posts by categories and tags
* [tweak] ALC: Post Slider - added option to display posts by categories and tags
* [tweak] Archive: Category description - tweaked style and paddings
* [update] Alchemists SCSS Compiler 4.2.1
* [fix] Search Form Widget button doesn't work on click
* [fix] Double menu item fields after WordPress 5.4 update
* [fix] Single Video - Text content is not displayed if "Separate video from the main content?" is enabled
* [fix] Some text strings weren't translatable
* [fix] Post hashtags, image description, image description sign color issues (eSports)
* [fix] Social Top Bar - fixed issued when social links aren't vertically aligned
* [tweak] Translation files updated

= 4.2.0 =
* [tweak] SportsPress 2.7 compatibility
* [tweak] WooCommerce 4.0.1 compatibility
* [tweak] ALC - Instagram Feed widget has been deprecated. Added Smash Balloon Social Photo Feed plugin to recommended
* [tweak] ALC: Event Scoreboard - added output for Time status
* [tweak] Event > Box Score - added output for Time status
* [tweak] ALC: Event Blocks - Small - added output for Time status
* [tweak] Countdown - added output for Time status
* [tweak] Footer Widget List Widget - removed divider between list items
* [tweak] Player Boxed - set full width for inner content
* [tweak] Event Logos - added classes to images (eSports)
* [tweak] Single Post > Post Nav - added margins between category labels
* [tweak] Theme Options > Content Filter - added text color option
* [tweak] VC Twitch - added additional check for tp_twitch_display_streams()
* [tweak] Theme Options - added option to change 'btn-default-alt' button colors
* [tweak] Theme Options - added option to change 'btn-primary' button colors
* [tweak] Theme Options - added option to change 'btn-primary-inverse' button colors
* [tweak] Video - Make image thumbnails clickable
* [tweak] ALC: Social Buttons - Update prefix icon class logos (Font Awesome 5)
* [tweak] Player Boxed - Added icon for Mixer
* [update] Alchemists SCSS Compiler 4.2.0
* [update] Alchemists Advanced Posts 2.0.3
* [update] ACF 5.8.9
* [fix] Video - thumb carousel doesn't show (RTL)
* [fix] Logo is not centered on Header Layout 4 (RTL)
* [fix] Social link in Top Bar - margin too big (RTL)
* [fix] ALC: Social Buttons - Missed YouTube icon logo
* [fix] Empty spaces in embeds for different providers
* [fix] Color - Player "More" button is not changing its color if customized
* [fix] Player Boxed - Fixed icon output for default social network (without specific icon)
* [fix] Fixes autoupdates for a child theme
* [fix] Theme Options > Single Player - added option to remove Player Header
* [fix] Button Primary - fixed issue with incorrect active state background color
* [fix] Small tweaks and improvements
* [fix] Nav - incorrect dropdown position (RTL)
* [fix] Event > Box Score > Staff - option doesn't disable Staff section

= 4.1.1 =
* [tweak] Theme Options - removed limitations to select different color schemes for different sports versions
* [fix] Theme Options - Footer Text Color option isn't available to customize
* [fix] Theme Options - Card Titles options aren't available to customize
* [fix] Theme Options - Logo custom position doesn't work in some cases

= 4.1.0 =
* [new] Sponsor Card element
* [new] Sponsor Cards element (for SportsPress Pro)
* [tweak] Footer Social Links - removed "@" sign for account names
* [tweak] ALC: Event Results - added option to display events for selected team
* [tweak] Updated screenshot for the child theme
* [tweak] Theme Options: Header → Secondary - added option to disable Header Secondary
* [tweak] Added changes to place Footer always at the bottom
* [tweak] Theme Options: Navigation - added option to customize side paddings
* [tweak] Theme Options: Search From - added option to change search form width
* [tweak] ALC: Text Ticker: small tweaks for different row layouts
* [tweak] Theme Options: added option to change button default colors
* [tweak] Content Filter: set active text as title color
* [tweak] Theme Options: added option to change body font for mobile devices
* [tweak] Theme Options: added options to customize Form Controls colors
* [tweak] ALC Recent Posts: added option to disable/enable Excerpt and Meta
* [tweak] Theme Options: added option to customize Table Colors separately
* [fix] Social Links - fixes issue with incorrect icon classes
* [fix] Megamenu divider color doesn't reflect on custom color changes
* [fix] ALC: Post Grid Slider - layout 3x3 might be broken if images have different height
* [fix] Colors: Fixed issue when Calendar active color wasn't reflecting on custom color changes
* [fix] Color: Accordion - custom colors weren't applied for accordion elements
* [fix] Footer: Copyright layout with Social Links didn't work for Basketball, Soccer, and American Football versions
* [fix] Radar Chart - double values in radar chart tooltips
* [fix] Radar Chart - custom statistics might produce errors on output
* [fix] "Final Score" string was not translatable in ALC: Event Results and Event Blocks widgets
* [update] Slider Revolution 6.2.2
* [update] Alchemists SCSS Compiler 4.1.0
* [update] Alchemists Advanced Posts 2.0.2
* [update] Advanced Custom Fields Pro 5.8.8
* [update] Translation files

= 4.0.3 =
* [tweak] Theme Options - added option to select Results and Schedule layout (list, blocks, blocks small)
* [tweak] Standings table border colors
* [tweak] Added Discord social network
* [tweak] Added Mixer social network
* [tweak] Video embed is not full width if Classic Editor used
* [tweak] Form controls custom color issues
* [tweak] Video - display video categories on Single Video page
* [tweak] Updated Telegram icon (from paper-plane to telegram-plane)
* [tweak] Added predefined page templates for eSports (Home v1, Home v2, Team, Player)
* [fix] Progress Lines custom color issue
* [fix] Header Layout 3 - fixed issue when Info Block items are not visible if enabled
* [fix] Header Info Block - custom icons are not vertically aligned
* [fix] Video List - border custom color issue
* [fix] Calendar Widget - left arrow icon is not displayed
* [fix] Video - post title layout position issue if titles is short
* [fix] ALC: Recent Post widget - display image placeholder if post doesn't have featured image
* [fix] Content Filter custom color issue
* [fix] Event List - buttons color issue
* [fix] Header - Shopping Cart icon isn't reflecting on custom changes
* [update] FontAwesome 5.12.1
* [update] Alchemists Advanced Posts 2.0.1
* [update] Alchemists SCSS Compiler 4.0.2
* [tweak] Small tweaks and fixes

= 4.0.2 =
* [tweak] Added Steam and Faceit social icons and links
* [tweak] Event Blocks - better handling for long team names
* [fix] Custom logo isn't changing for Header Layout 4
* [fix] Header Layout 1 custom background color isn't applying
* [fix] ALC: Text Ticker - fixed issue when full width displayed incorrectly
* [fix] Header Layout 4 - Header Primary color isn't reflecting on custom changes
* [fix] ALC: Featured Post - image display issue
* [update] Alchemists SCSS Compiler 4.0.1

= 4.0.1 =
* [fix] Small tweaks and fixes

= 4.0.0 =
* [new] eSports version
* [new] Sponsors - added option to select Sponsors position (before/after Footer Widgets)
* [new] Sponsors - added option to changes Sponsors' background
* [new] Footer Secondary - added new option to display Social Links
* [new] Post Tags - added option to select between 'button' and 'hashtag' type for post tags
* [new] Footer Widgets - added option to add overlays for Footer Widgets Background (Simple, Duotone, Off)
* [new] Page Heading - added option to select different layouts
* [new] Page Heading - added option to apply duotone effect to Page Heading
* [new] Header - added 2 prebuilt Header Layouts (4 overall) and option to easily customize it
* [new] Header Shopping Cart - added option to select action (click, hover)
* [new] Header Social Links - added option to select links position (Top Bar, Header Primary)
* [new] ALC: Box Info - added new element to display various short information
* [new] ALC: Jumbotron - added new element to showcase hero unit style content.
* [new] ALC: Accordion - added new element to display content with collapsible panels.
* [new] Posts Filter - added new style (Boxed)
* [new] DF Social Count - added new layout for counters (Buttons)
* [new] Post - added 3 new post layouts
* [new] Video Post format - added a separate styling for Video Post Format
* [new] Video Custom Post Type - added a new custom post type for displaying videos
* [new] Recent Videos - added new widget displays recent Video Post Formats
* [new] My Account - added horizontal navigation on My Account page
* [new] Single Player - added new Boxed layout for single player page (for all sports)
* [new] ALC: Post Loop - added Cards Tile - 2 cols layout
* [new] ALC: Player Stats - Chart - added new element to represent player stats in Doughnut and Horizontal Bars charts
* [new] ALC: Player Stats Graph Log - added new element for displaying Player Stats log with Line chart
* [new] ALC: Player Stats Grid - added new element to display Player Stats in Grid layout
* [new] ALC: Achievements - added new element to represent static information in sliding format
* [new] ALC: Description List - added new element to display information in description list
* [new] Team > Gallery - added new design for albums (Image Top + Thumbs + Title Bottom)
* [new] Added Slider Revolution plugin
* [new] ALC: Post Grid - added 1-2 Card Tile and 1-2-1 layouts
* [tweak] ALC: Recent Posts widget - added new Small - Wide image size
* [tweak] Header - added option to set different Header Layouts
* [tweak] Header Nav - min height changed to 30px
* [tweak] Card Header Title - added option to customize Card Header Title's Typography
* [tweak] Blog v5 - allow to use Blog v5 layout for Basketball and Soccer
* [tweak] Albums - added option to customize Albums slug
* [tweak] Shop - added option to disable product gradients
* [tweak] Footer List Widgets - added option to customize typography for list-based widgets in the Footer Widget area
* [tweak] Event Video - tweaks video embed output by adding responsive container
* [tweak] Card Header Button changed from outline to filled (American Football)
* [tweak] League Table - 'Preview' and 'Article' links were changed to buttons
* [tweak] WooCommerce 3.9 compatibility
* [tweak] Player Blocks - don't output empty metrics (height, weight)
* [tweak] ALC: Post Loop - added new layout List - Card Tile Small
* [tweak] ALC: Text Ticker - added boxed layout with rounded corners
* [tweak] ALC: Text Ticker - added option to display Categories
* [fix] Fixed issue when custom Footer Widgets Background Image isn't applied
* [fix] DF Social Count - updated Twitch v3 API (kraken) to new API (helix)
* [fix] WooCommerce - fixed issue when rating icons disappeared on hover
* [fix] ALC: Team Leaders - fixed issue when players aren't sorted correctly by total rebounds (Basketball)
* [fix] Image Captions - fixed issue with incorrect styling for image captions with different alignments
* [fix] ALC: Newslog - fixed issue when some icons are not displayed correctly
* [fix] ALC: Event Results - fixed issue with output enabled by empty Timeline (Soccer)
* [fix] Widget Lists - fixed issue when markers displayed for list based widgets inserted with page builder
* [fix] Hero Unit Posts Slider - fixed issue when custom height is not applied if Navigation Type set to Numbers
* [update] Alchemists SCSS Complier 4.0.0
* [update] DF Social Count 1.2.0
* [update] WPBakery Page Builder 6.1
* [update] Alchemists Advanced Posts 2.0.0
* [update] Alchemists WooCommerce Grid / List toggle 1.1.3
* [update] Alchemists Color Filters for WooCommerce 1.0.3

= 3.5.1 =
* [update] WPBakery Page Builder 6.1
* [update] Translation files
* [tweak] Small tweaks and improvements

= 3.5.0 =
* [new] New Theme Activation mechanism based on Purchase Code
* [tweak] Small tweaks and improvements

= 3.4.1 =
* [tweak] Player - added option to display Team Logo on the single player page
* [tweak] Blog - added Blog style customization to Archive page
* [tweak] SP Event Blocks - added action to events which allow adding custom functionality
* [tweak] ALC: Player Game-by-Game stats - added CSS classes on each table cell
* [tweak] SP Player Details - improved layout on mobile and tablet devices
* [update] ACF 5.8.7
* [update] WooCommerce 3.8.0 compatibility
* [tweak] Small tweaks and improvements

= 3.4.0 =
* [new] Home - Version 2 page was added for American Football
* [new] ALC: Post Grid Slider - added new layout (1-2)
* [new] ALC: Roster Carousel
* [new] ALC: Post Grid
* [new] ALC: Event Results - added expand/collapse button
* [new] Widget: Recent Posts - added new layout (Thumbnail - Extra Large)
* [tweak] SP Event - improved styling for events on Archive page
* [tweak] Event - added option to enable Comments on Single Event page
* [tweak] SP Player List - improved player photo output
* [tweak] ALC: Team Leaders - replacef placeholder image to a smaller one
* [tweak] ALC: Event Results - added customization option to select performance
* [tweak] DEV Browserlist - removed old and deprecated properties used for outdated browsers
* [tweak] Single Player - Radar Chart is reworked and now displays relative chart if Player List is selected (Basketball)
* [tweak] Theme Options: Single Player - added Players Statistics as data source for Player Radar (Basketball)
* [tweak] Theme Options: Team Gallery - added option to select Gallery type
* [tweak] Theme Options: Albums - added option to select Single Album layout (fixed, full width)
* [tweak] Theme Options: added option to select Footer Secondary (Copyright) layout
* [tweak] Widget: Countdown - added 'Read More' button (Football)
* [tweak] ALC: Roster Blocks - added option to select Player Metrics
* [tweak] ALC: Roster Carousel - added option to select Player Metric
* [tweak] ALC: Roster Blocks - added option to hide Age, Nationality, and Flags
* [tweak] ALC: Roster Carousel - added option to hide Age, Nationality, and Flags
* [tweak] ALC: Contact Info widget - added 2 fields for custom social networks
* [tweak] Demo Data updated
* [update] Alchemists SCSS Compiler 3.0.8
* [update] Alchemists Advanced Posts 1.2.0
* [update] ACF 5.8.5
* [update] Traslation files
* [tweak] Small tweaks and improvements
* [fix] Duotone effect didn't work correctly in some parts
* [fix] Woo - fixed broken layout on My Account > Addresses page
* [fix] Styling - Card Clean Header color wasn't reflecting on custom color changes

= 3.3.2 =
* [tweak] WooCommerce - added option to enable/disable sidebar on Single Product page
* [tweak] ALC: Games History - added Draws for Soccer
* [tweak] ALC: Game-by-Game Stats - static labels were replaced with dynamic ones (Soccer)
* [tweak] ALC: Team Leaders - set 'eventsattended' only for Basketball and use 'eventsplayed' for other sports
* [tweak] Theme Options: add option to remove Featured Image on single posts
* [tweak] Theme Options: Typography - added additinal various typography options
* [tweak] Theme Options: Single Post - added option to customize Overlay (simple, duotone, none) for Single Blog Post 3 layout
* [tweak] SVG-based duotone replaced with CSS-based for easy modification
* [tweak] Small tweaks and improvements
* [fix] WooCommerce - broken form layouts, e.g. Checkout page

= 3.3.1 =
* [tweak] Single Event - circular bars and progress bars aren't displayed if empty
* [tweak] Team Gallery - clickable area of Player Images covers the full image
* [tweak] Dev - added filters for fonts in Theme Options
* [fix] Markers for list (ul) items
* [fix] Mega Menu columns aren't equal if class is not specified
* [fix] Header Search icon isn't displayed on mobile devices
* [fix] Content Filter icon isn't displayed on mobile devices
* [fix] American Football sample data fixed
* [fix] ALC: Event Results - same colors for progress bars if Team Color is not specified

= 3.3.0 =
* [new] Bootstrap 4
* [new] Team Colors - added option to set different colors for different teams
* [new] ALC: Team Stats - added option to display custom icons
* [new] Theme Options - added option to globally disable Likes
* [new] Theme Options - added option to globally disable Views
* [new] Theme Options - added option to globally disable Comment Count
* [new] Team Roster - added option to display Staff
* [new] ALC: Social Buttons - added YouTube button
* [new] FontAwesome 5
* [tweak] RTL improvements and tweaks
* [tweak] Theme Options - added option to customize Pushy Panel background color
* [tweak] ALC: Player Stats and Featured Player - '2-pointers' replaced with default 'field goals' inside template files (Basketball)
* [tweak] Featured Player - added "AVG" label to Efficiency rating (Basketball)
* [tweak] ALC: Roster Blocks - added option to remove Squad Number
* [tweak] Theme Options - added additional Categories groups
* [tweak] Dev - added 'alc_site_content_before' and 'alc_site_content_after' hooks
* [tweak] Team Schedule - added option to select Calendar
* [tweak] Team Latest Results - added option to select Calendar
* [tweak] ALC: Team Points History - better compatibility with different sports
* [tweak] ALC: Staff Bio Card - added option to select Image Size
* [tweak] Improve Cards displaying on tablet devices
* [tweak] Woo - added link to product image
* [tweak] Event Scoreboard - allow to use more than one element and shortcode
* [tweak] Theme Options - add option to open Header Banner in a new tab
* [update] WooCommerce 3.7.0 compatibility
* [update] ACF 5.8.3
* [update] DF Social Count 1.1.1
* [update] Alchemists SCSS Compiler 3.0.7
* [update] Alchemists Advanced Posts 1.1.5
* [fix] Event: Events Blocks - pagination isn't displayed
* [fix] Header Search Input - incorrect color if not focused
* [fix] RTL - Event circular bar statistics are in wrong order
* [fix] Single Player - vertical Circular Bars are not correct circle

= 3.2.7 =
* [update] SportsPress 2.6.20 compatibility
* [update] WPBakery Page Builder 6.0.5
* [update] ACF 5.8.2
* [tweak] Added Match Day output for Countdown and Event Blocks
* [tweak] Disabled Responsive Tables by default on Sample Data Import
* [tweak] Added `alc_vc-posts-number` filter for posts number parameter
* [tweak] ALC: Post Loop - added optio to enable pagination
* [tweak] Added Staff Page Template to WPBakery Page Builder templates
* [tweak] Event - display Match Day on Single Event page and ALC: Event Scoreboard if enabled
* [fix] WooCommerce WPBakery Page Builder products elements were fixed
* [fix] Event Logos Blocks - opposite team's circular bars have no colors if Quaternary Color - Alt is not set
* [fix] ALC: Team Leaders - columns aren't aligned vertically in some cases
* [fix] ALC: Event Scoreboard - PHP notices if 'details' disabled (Basketball, American Football)

= 3.2.6 =
* [update] SportsPress 2.6.19 compatibility
* [tweak] Event Blocks - now display event venues
* [tweak] ALC: Post Loop - added option to select Image Size
* [tweak] ALC: Post Slider - added option to select Image Size
* [tweak] Team Roster Blocks - reworked with flexbox
* [tweak] Team Roster Gallery - reworked with flexbox
* [tweak] Theme Options - added option to change color for Social Links in the Header
* [tweak] Added RTL compatibility for Social Counters
* [fix] Timeline Vertical - logos were misaligned
* [fix] Single Team Page Heading options didn't work on Single Team
* [fix] Mobile menu - long item names weren't handled correctly

= 3.2.5 =
* [update] SportsPress 2.6.17 compatibility
* [update] ACF 5.8.1
* [tweak] Hero Unit - Static - added option to open links in a new tab
* [fix] Player Blocks undefined variable 'number'
* [fix] Player Stats in Player Cards aren't displayed for Current Season
* [fix] Player Stats in Player Cards Slide aren't displayed for Current Season
* [fix] Player Stats in Player Carousel aren't displayed for Current Season
* [fix] RTL - Timeline layout is broken for RTL sites
* [fix] RTL - Countdown timer wrong order for numbers
* [fix] Theme Options - Custom performances, metrics and stats displayed in a wrong order

= 3.2.4 =
* [fix] Small fixes and performance improvements

= 3.2.3 =
* [tweak] ALC Team Leaders - added option to order players by AVG stat
* [tweak] Social - added Twitch social link (Header, Footer and Contact Info widget)
* [tweak] WooCommerce 3.6.0 compatibility
* [update] Slick.js 1.9.0
* [fix] ALC Awards Carousel - empty images
* [fix] SP Event Blocks doesn't display events if format is set to 'Default'
* [fix] ALC Team Leaders - Games Played parameter show only started games

= 3.2.2 =
* [tweak] ALC Event Results widget - added Sorting Order option
* [tweak] ALC Event Scoreboard - display last game for current team if event not specified
* [tweak] ALC Event Scoreboard - added option to select a team if Last Event option is enabled
* [tweak] Social - added Snapchat social link to Header, Footer and Widget Contact Info
* [tweak] SportsPress - added option to display player stats in various parts for Current Season (early only Career Total)
* [tweak] ALC Player Game-by-game - display only played games for selected player with option to display all games
* [tweak] ALC Roster Slider - added 'autoplay' and 'autoplay speed' options
* [tweak] ALC Event Scoreboard, Single Event - output Own Goals and selected icons
* [update] ACF 5.7.13
* [fix] Theme Options - Quaternary Alt color is not displayed if no preset used (Soccer, Football)
* [fix] Incorrect text color in Tournament brackets (appeared on dark skins)
* [fix] Duplicated players pictures in Team Roster if Lazyload used

= 3.2.1 =
* [tweak] Added Telegram social link to Header, Footer, Post sharing buttons
* [tweak] Theme Options - added option to customize Hero Unit - Static: Decoration (starts)
* [tweak] Theme Options - added option to customize Hero Unit - Static: Title text color
* [tweak] Theme Options - added option to customize Hero Unit - Static: Subtitle text color
* [tweak] Theme Options - added option to hide Page Title Text
* [tweak] Theme Options - added option to change Page Title tag
* [tweak] VC: ALC Roster Blocks - added option to overwrite number of players
* [tweak] Optimized backend for high loaded sites
* [update] WPBakery Page Builder 5.7
* [update] ACF 5.7.12
* [update] WooCommerce 3.5.5 compatibility
* [dev] Added filter for Team and Player slugs
* [fix] Theme Options > Hero Posts Slider - Overlay opacity color isn't applied
* [fix] Event Scoreboard - circular Bar color for the Second Team is not customizable

= 3.2.0 =
* [new] RTL support
* [new] Theme Options - added option to customize Header Mobile background
* [new] ALC: Text Ticker - added option to include specific posts (by title)
* [new] Theme Options - added option to customize colors for Links inside Headings (h1-h6)
* [new] Theme Options - added option to hide Timeline
* [new] SP Event Scoreboard - added option to link the event
* [new] Theme Options - Mobile menu - added option to set submenu caret background color
* [new] Theme Options - Mobile menu - added option to set fullwidth mobile menu
* [new] Theme Options - added option to change link colors inside outline buttons
* [new] Theme Options - Mobile menu - added option to customize mobile menu font size
* [new] Theme Options - added option to customize color of the burger menu icon
* [tweak] Removed old Social Counters
* [tweak] Moved widgets to a separate plugin according to new ThemeForest WordPress Requirements
* [tweak] Removed ALC: Ad Spot widget
* [tweak] SP Single Player Header - don't show advanced stats if customization option enabled but fields were not selected
* [tweak] Woo - added page heading customization option for Shop pages
* [tweak] SportsPress Pro 2.6+ better compatibility
* [tweak] WP Queries optimization
* [fix] Hero Unit - author avatar alignment issue if numbers enabled (Soccer)
* [fix] Menu - submenu dropdown caret color (Soccer)
* [fix] SP Pro - Event Performance layout issue (appears if SportsPress Pro activated)
* [fix] SP Pro - League Menu, Scoreboard, Sponsors overlaps navigation on mobile devices
* [fix] SP - Player Birthdays fixed (PHP notice)
* [update] ACF 5.7.10
* [update] jQuery.Marquee 1.5.2
* [tweak] Other minor bug fixes and performance improvements

= 3.1.0 =
* [tweak] WordPress 5.0 compatibility
* [tweak] WooCommerce 3.5.3 compatibility
* [tweak] SportsPress 2.6.14 compatibility
* [tweak] Woo - Better styling for bank information section on Checkout "Thank You" page
* [tweak] Event - Event statistics aren't displayed for Player-vs-Player mode
* [update] WPBakery Page Builder 5.6
* [update] ACF 5.7.8

= 3.0.13 =
* [update] WPBakery Page Builder 5.5.5
* [update] Alchemists SCSS Compiler 3.0.4
* [update] Advanced Custom Fields 5.7.7
* [tweak] SportsPress 2.6.10 compatibility
* [tweak] WooCommerce 3.5.1 compatibility
* [tweak] Theme Options: Added options to customize Logo Image path
* [tweak] ALC: Roster Blocks - don't display Height, Weight if they're empty or not exist
* [tweak] Removed unnecessary esc_html from 404 page
* [tweak] Improve sanitization for Primary, Secondary email, link, tel
* [fix] Content Nav colors are not changin with Card colors after customization
* [fix] Scrollbar disappears if menu was opened on tablet portrait mode and then changed to landscape mode
* [fix] Multiple ALC: Roster Slider elements trigger JS error
* [fix] SP: Single Player Radar - notice appeared if Total option is not checked
* [fix] PHP 7.2+ compatibility fix
* [fix] ALC: Event Scoreboard - wrong event date (American Football only)
* [fix] Other minor bug fixes and performance improvements

= 3.0.12 =
* [tweak] SportsPress 2.6.8 compatibility
* [tweak] WooCommerce 3.4.4 compatibility
* [tweak] Theme Options: added dropdown carets color customization
* [tweak] Widget Contact: added option to enter tel number for Primary and Secondary fields
* [tweak] Theme Options: added option to enter tel number for Primary and Secondary fields in the Header
* [tweak] Addede option to customize Album Page Headings
* [tweak] ALC: Contact Info widget - added option to use simple links
* [fix] ALC: Staff Bio Card - improved 3 columns width layout
* [fix] SP Team Roster block improved layout on mobile devices

= 3.0.11 =
* [tweak] VC: ALC Post Slider - link only thumbnail instead of whole content
* [tweak] Theme Options - tweak for Player Heading Overlay option
* [tweak] VC: ALC Featured Post - added option to output formatted custom excerpt
* [tweak] Theme Options: Player Heading Background - don't show default background image if customization option enabled and no background image has been set
* [tweak] Theme Options: Single Post - added option to disable author email and site link
* [tweak] Theme Options: Top Bar - added option to change dropdown colors
* [tweak] Theme Options: Player - added option to customize 'Player' sublabel
* [update] SportsPress 2.6.7 compatibility
* [fix] Countdown - Card Subheader color customization issue
* [fix] Other minor bug fixes and performance improvements

= 3.0.10 =
* [tweak] Theme Options: Added option to upload custom preloader(spinner) image (e.g. gif)
* [tweak] Theme Options: Navbar min-height changed to 40px
* [tweak] VC: Added Team Overview page template for American Football version
* [tweak] Theme Options: Hero Unit Posts Slider - added option to disable post title
* [tweak] Theme Options: Hero Unit Posts Slider - added option to link post slide
* [tweak] Team: Added option to output multiple Team Rosters
* [tweak] Theme Options: Team - added option to customize 'The Team' label
* [tweak] VC: ALC Post Loop - added option to exclude posts by ID
* [tweak] SP: Added option to customize Page Headings for Events, League Tables and Calendars
* [tweak] Translation: Improved SportsPress text strings translation
* [update] WPBakery Page Builder 5.5.2 (formerly Visual Composer)
* [update] Translation files updated
* [fix] SP: Category notice on Venue/Ground archive page
* [fix] SP: Player Header - error appeared if seasons are not selected (Soccer)
* [fix] Hero Unit Posts Slider - sliding thumbs issue
* [fix] Other minor bug fixes and performance improvements

= 3.0.9 =
* [tweak] Replaced existing Social Counters with DF Social Count plugin. New social counters added: Github, Pinterest, Steam, Tumblr, Twitch, Vimeo, YouTube and additional site counters Comments, Posts and Users.
* [tweak] WooCommerce 3.4 compatibility
* [tweak] VC Awards Carousel - added option to enable autoplay (+autoplay speed)
* [tweak] Theme Options: Added option to change Megamenu Post Widget Text and Meta colors
* [tweak] Single Post: Added additional checkbox to post comment form if user non-logged users (WordPress 4.9.6 compatibility)
* [fix] Other minor bug fixes and performance improvements

= 3.0.8 =
* [tweak] Theme Options: Mobile Logo - added option to display a separate logo on tablet and mobile devices
* [tweak] VC ALC: Team Leader - added option to customize table columns headings
* [tweak] Blog - added option to customize Blog/News page separately
* [tweak] VC ALC: Team Points History - added ability to display multiple elements
* [tweak] VC ALC: Games History - added ability to display multiple elements
* [tweak] TGMPA - display plugin notices only for admin
* [fix] Blog - incorrect social cards width on Tablets
* [fix] Header - Social Links incorrect alignment if Pushy Panel is not enabled
* [fix] SP: Single Player Header - error notices if Player List is not selected
* [fix] Footer: Widgets - incorrect columns width in some cases
* [fix] Other minor bug fixes and performance improvements

= 3.0.7 =
* [new] Product Registration (via Personal Token)
* [tweak] SportsPress 2.6+ compatibility
* [tweak] Theme Options: Single Post - added option to disable post navigation
* [tweak] Theme Options: Single Post - added option to select type of post navigation
* [tweak] Theme Options: Added a separate Sidebar Position option for Single Post Layout
* [tweak] Theme Options: Added option to select between Horizontal or Vertical Timeline Layout on Single Event page (Soccer)
* [tweak] VC: ALC Newslog Static - added new types
* [tweak] SP: Player Bio Events - added new types
* [tweak] Added Chinese translation (thanks to @zxm159789)
* [tweak] Translation updated
* [update] Documentation updated
* [fix] SP: Timeline - fixed broken layout when entered a lot of match timed events (Soccer)
* [fix] Other minor bug fixes and performance improvements

= 3.0.6 =
* [tweak] Sync image duotone effect colors with main colors (American Football)
* [tweak] SP: Single Player - add 'avg' or 'tot' abbreviation to circular bars depends on stat type
* [tweak] WooCommerce Grid / List toggle plugin replaced with Alchemists WooCommerce Grid / List toggle plugin
* [tweak] Color Filters WooCommerce plugin replaced with Alchemists Color Filters for WooCommerce plugin
* [tweak] SP: Single Player Header - added option to change some strings via SportsPress panel
* [tweak] VC: Post Loop - added Excerpt Size option
* [tweak] Added Twitter Card meta tags (better Twitter Cards support)
* [update] ACF 5.6.10
* [fix] Some strings missed translation function in Player Cards (Soccer)
* [fix] Some letters are higher than other when using Exo 2 font (American Football)
* [fix] Woo: 'WC_Cart::get_item_data' deprecated function
* [fix] Woo: Header Cart - no submenu arrow in some cases
* [fix] Woo: Shop 'Add-to-cart' AJAX button doesn't work
* [fix] Woo: Select dropdown color issue
* [fix] Other minor bug fixes and performance improvements

= 3.0.5 =
* [tweak] Widget ALC: Event Results - added relative date range option which allows to display last event(s) of relative period e.g. last 7 days (similar to Event Blocks)
* [tweak] Widget: ALC: Top Posts - added Popularity definition (likes or views)
* [tweak] Widget: ALC: Recent Posts - added Popularity definition (likes or views)
* [tweak] Improved post sharing by adding Open Graph (can be disabled via Theme Options in case you're using third-party plugin)
* [tweak] Theme Options: Typography - added Footer Widgets typography customization options
* [tweak] Theme Options Added option to change card colors (box)
* [tweak] Theme Options: Added additional Categories groups (up to 5)
* [tweak] Theme Options: Prevent adding incorrect characters to slugs for SportsPress Team, Player
* [tweak] Theme Options: Added email and RSS icons to Social Media Links
* [tweak] Display Header Banner on mobile devices
* [tweak] SportsPress Player Statistics - changed Leagues order to 'menu_order'
* [update] Sample Data files
* [update] Translation files
* [fix] Footer Logo on/off option doesn't work
* [fix] Other minor bug fixes and performance improvements

= 3.0.4 =
* [tweak] SportsPress Countdown - display team names even if a team logo is not set
* [tweak] Theme Options - Added various divider types and option to remove it for the Header Top Bar menu items
* [tweak] SportsPress: Event Result - added options to select stats in Theme Options > SportsPress > Event. Also affected on ALC: Event Scoreboard element
* [tweak] Widget: Featured Player - added option to disable link to player profile
* [tweak] ALC: Player Stats - added option to disable link to player profile
* [tweak] Widget: ALC: Event Results - added option to on/off Game Statistics
* [tweak] Widget: Contact Info - added option to customize icons
* [tweak] Added Spanish translation
* [update] WPBakery Page Builder 5.4.7
* [update] ACF 5.6.9
* [fix] SportsPress: Event goals section contains the event result (Soccer)
* [fix] ALC: Posts Grid Slider - tags filter doesn't work
* [fix] Removed search icon on mobile devices if search form disabled
* [fix] SportsPress: Wrong order for custom Event Results (Single Event, ALC: Event Scoreboard, ALC: Event Results widget)
* [fix] Added American Football Home Page template
* [fix] Hero Unit - Posts Slider: incorrect post title font size on mobile devices

= 3.0.3 =
* [tweak] WooCommerce 3.3.3 compatibility
* [tweak] Added option to custom Single Player Header Metric, Statistics and Performances
* [tweak] SportsPress: Sport icon in the Dashboard Side Menu has been changed if American Football preset used
* [tweak] Added vertical paddings to Header Banner
* [fix] Woo: Grid/List settings disappeared after WooCommerce 3.3.1 release
* [fix] Removed unnecessary player image in Hero Posts Slider
* [fix] Other minor bug fixes and performance improvements

= 3.0.2 =
* [fix] Update for Alchemists SCSS Compiler plugin

= 3.0.1 =
* [tweak] Added option to link Sponsors (compatibility with WP Gallery Custom Links plugin)
* [tweak] Fallback for duotone images - IE11 and Edge
* [tweak] Added a single post option to select Single Post - version 5
* [tweak] Added option to select Roster Slider for Team (Soccer)
* [fix] Post next/previous broken layout (Football)
* [fix] Better wrap for progress bars on Edge browser (Football)
* [fix] Widget: Last Game Results - horizontal scrollbar on Edge browser (Basketball)
* [fix] 'Exo 2' Google Font issue (P and R) on Edge browser
* [fix] VC: Featured Post - overlay color and image padding issues on Edge browser (Basketball)
* [fix] Loading issue on IE11 (endless preloader)
* [fix] Custom Icons in the Footer are not affected on changing color
* [fix] Small tweaks and fixes

= 3.0.0 =
* [new] American Football version
* [new] Hero Posts Slider - numbered nav
* [new] Theme Options - Added option to enable/disable Hero Unit Posts Slider overlay
* [new] Theme Options - Added option to customize color for Hero Unit Posts Slider overlay
* [new] Hero Posts Slider - duotone images
* [new] Widget: Top Posts - added option to enable/disable post excerpt
* [new] Widget: Top Posts - added option to enable/disable post thumbnail
* [new] Widget: Event Results - added vertical layout
* [new] ALC Post Grid Slider
* [new] ALC Text Ticker for Posts
* [new] Widget Recent Posts - Extra Small Layout
* [new] Widget Recent Posts - Numbered List
* [new] Header Banner
* [new] Single Post - Version 4
* [new] Widget: Recent Comments - new layout
* [new] 36 new PSD files of the American Football (84 in total)
* [tweak] Widget Recent Posts - Added hover effect on thumbnails
* [tweak] Option to select Search Form position (Header Primary or Header Secondary)
* [tweak] Instagram Widget - now able to display shots using base settings (Theme Options > Social) if widget fields are empty
* [tweak] WooCommerce Shipping block styling improvements
* [tweak] Single Player Header - don't display empty Height & Weight metrics
* [tweak] Added pagination for posts/pages
* [tweak] ALC Albums - new type (Heading Top)
* [fix] ALC Event Scoreboard team custom colors (Soccer)
* [tweaks] Small tweaks and fixes

= 2.3.1 =
* [tweak] SportsPress 2.5.7 compatibility
* [tweak] Theme Options - added option to add a custom class for Hero Static - Button
* [tweak] Responsive tables styling improvements
* [tweak] Theme Options - added option to customize Top Bar links color
* [fix] Seach Form placeholder typo
* [fix] Removed Recent Posts Widget list markers if it's used with Widgetized Sidebar
* [fix] League Table pagination doesn't work
* [fix] Single Player Header layout is broken on IE11
* [fix] Product Title incorrect width if description is short or empty
* [fix] Team Page - option to disable List Roster on a Team doesn't work
* [fix] Theme Options - fixed 'transparent' color checkbox position

= 2.3.0 =
* [new] Added SportsPress Pro compatibility
* [tweaks] Small tweaks and fixes

= 2.2.3 =
* [fix] Check for an empty Timeline (Soccer version)
* [tweak] Removes recommendation to install SportsPress if SportsPress Pro already installed

= 2.2.2 =
* [tweak] Improved Event Title displaying for scheduled and published events
* [tweak] Event Staff - added more space between staff members
* [update] ACF 5.6.7
* [fix] Alchemists SCSS Compiler update issue

= 2.2.1 =
* [update] WPBakery Page Builder (formerly Visual Composer) 5.4.5
* [update] SP Event - changed title for scheduled events
* [fix] Woo - variable product bug with price
* [fix] SP Event - added style for Staff block
* [fix] SP Countdown widget - removed extra div after the update 2.2.0
* [tweak] Tooltip active after click

= 2.2.0 =
* [new] SportsPress 2.5 compatibility
* [new] Team Roster Cards and VC Roster Cards (for Soccer)
* [new] Team Roster Blocks and VC Roster Blocks
* [new] SP Single Player - added new player info layout
* [new] SP Game Timeline (for Soccer)
* [tweak] Added post sharing button to Post Version 3
* [tweak] Sort teams by 'title' in all VC elements
* [tweak] SP Single Player Header - added option to hide extended stats in the page header
* [tweak] Countdown Widget (Soccer) - restyled
* [tweak] Added Post Option to change layout on different posts
* [tweak] Added option to reorder, enable, disable post filter items
* [tweak] Added Hero Unit Description font color option
* [tweak] Added Custom Page Heading Options for separate pages, team and player
* [tweak] VC: Albums - added pagination
* [tweak] VC ALC: Games History - prevent js error if season includes non-number character
* [tweak] SP Single Player - added more details to display if enabled(Past Teams, Birthday, Competitions, Seasons)
* [update] ACF 5.6.5
* [update] Visual Composer 5.4.4
* [fix] Social Counter - count numbers displayed multiple times for multiple widgets
* [tweak] Small tweaks and improvements

= 2.1.1 =
* [tweak] Display Header Top submenus on mobile devices
* [tweak] Enqueue Chart.js script separately
* [tweak] Enqueue child theme stylesheet after all styles
* [tweak] Hero Unit Posts Slider: added autoplay option
* [tweak] Hero Unit Posts Slider: added autoplaySpeed option
* [tweak] SportsPress: Don't show filter bar if only the Overview subpage selected (team, player)
* [tweak] VC Player Stats - added options to select statistics
* [tweak] VC ALC: Player Game-by-game stats - display labels instead of variables
* [tweak] Single Player - display player details depends on SportsPress Player Options
* [tweak] Small tweaks
* [update] Translation file

= 2.1.0 =
* [new] WPML compatibility
* [new] VC Post Loop - new layout
* [new] Post Social Sharing - added Viber and WhatsApp buttons
* [new] Top Bar links replaced with Top Menu
* [tweak] Taxonomies (tags, categories) pages now display descriptions
* [tweak] Hero Unit Posts Slider - added new options to hide post info (meta, categories, author)
* [tweak] Hero Unit Posts Slider - added height options
* [tweak] Contact Form 7 image loader replaced with CSS loader
* [tweak] Ball Possession displays progress without % (Soccer)
* [tweak] Added ability to set both links and email address in the Header
* [tweak] ALC: Player Game-by-Game - changed date format to default
* [tweak] WooCommerce 3.2 compatibility
* [fix] Alert Warning Color (Soccer)
* [fix] Search Close Icon in the Header on mobile devices
* [update] Visual Composer 5.4.2
* [update] ACF 5.6.3
* [update] Demo Data files
* [update] Translation file

= 2.0.3 =
* [tweak] Blog Pagination Soccer styling
* [tweak] Improved Staff Bio Card title for long names
* [tweak] Added links to Featured Player element and widget
* [tweak] League Table td-tag text colors (Soccer)
* [tweak] Statistics Circular Bars on Single Player Page are dynamic now (if Player List selected)
* [tweak] Average stats Circular bars in VC Team Leaders are dynamic now
* [tweak] Changed Single Album description on hover effect (Soccer)
* [tweak] Added guides to generate Social Profiles credentials
* [tweak] Added predefined VC Page Templates
* [tweak] SportsPress Birthdays Widget restyled
* [fix] Fixed issue when you need to deactivate Redux Framework to change SportsPress fields
* [fix] Dropdown Menu z-index
* [update] Translation file

= 2.0.2 =
* [tweak] Logo - added Logo Position Adjustments option
* [tweak] ALC: Posts Widget - added Category field
* [tweak] ALC: Contact Info widget - added Instagram link
* [tweak] Added ability to define last name for player
* [tweak] Theme Options - added Single Player Header Background option
* [tweak] Dashboard notices now can be dismissed
* [fix] Redux Dimensions field fix (appears after update to Redux Framework 3.6.7)
* [update] Visual Composer 5.3
* [update] ACF 5.6.2
* [update] Translation file

= 2.0.1 =
* [new] Croatian Language (Thanks to @zskiljan)
* [tweak] Check for empty products gradients
* [tweak] ALC: Event Scoreboard, ALC: Event Result, Event take statistics labels, description from SportsPress
* [tweak] Added shrink-to-fit meta tag for iOS devices
* [tweak] Added Customized Content Top and Bottom padding in Theme Options
* [tweak] ALC: Event Scoreboard - added option to hide/show detailed statistic
* [fix] "Ball Possession" incorrect spelling
* [fix] Ball Possession progress bar displayed incorrectly on Firefox
* [fix] Tags Cloud widget hover text color
* [fix] VC Games History fixed float number
* [fix] Mobile Menu background color
* [fix] Disabling Link Events option doesn't work for some VC elements and widgets
* [fix] Player Metrics now based on Variables (previous Labels). Fixes issue when Player Metrics Labels were changed, e.g. another language
* [misc] Various minor fixes tweaks
* [update] Translation file

= 2.0.0 =
* [new] Soccer version
* [new] 2 color predefined scheme
* [new] Hero Posts Slider
* [new] 14 New PSD files (46 overall)
* [tweak] Various tweaks and fixes

= 1.3.0 =
* [new] Roster Slider as Visual Composer element
* [tweak] Widget Top Post - changed order for Popular Posts output
* [tweak] Changed Schedule table order option DESC->ASC (closest go first)
* [tweak] Post Loops improvements
* [tweak] Styling tweaks for Footer Menu links size on mobile devices
* [fix] Widgets without titles (e.g. ALC: Social Counters) breaks layout if placed in Footer Widget Area
* [fix] RSS Widget has some styling issues if used in VC Widgetized Sidebar
* [fix] Contact Widget - incorrect labels and icons for Twitter and Facebook
* [fix] Venue link not displayed correctly
* [update] Translation file

= 1.2.0 =
* [new] Added options to change Single Team subpages labels, slugs and order
* [new] Added options to change Single Player subpages labels, slugs and order
* [new] Added Blog Categories Color Options
* [update] Visual Composer 5.2.1
* [update] ACF 5.6.1
* [tweak] SportsPress for Basketball removed from TGMPA
* [tweak] VC - Removed side padding for non-responsive layout
* [tweak] VC - Games History element default chart line color
* [tweak] VC - Points History element default charts color
* [fix] Single Team and Single Player subpages slug
* [fix] Event Block - fixed long team names
* [fix] Widget Blog Posts on some pages don't have Comments
* [misc] Other small fixes and tweaks

= 1.1.0 =
* [new] 25 New Styling Options
* [new] VC Albums Element
* [new] VC Content Nav Element
* [tweak] Added new option to removed Top Bar links - Theme Options > Header > Top Bar > Show/Hide Links
* [tweak] Added new option to remove categories - Theme Options > Blog & Posts > Show Categories?
* [tweak] SportsPress removed not used options
* [tweak] Predefined SportsPress options after demo import
* [fix] VC - Post Carousel alignment for short Post Title
* [fix] Single Player Radar Chart custom color
* [fix] Post Author empty fields
* [update] Translation file

= 1.0.4 =
* [tweak] Replaced anonymous function for site-url (PHP 5.2 fix)
* [tweak] Countdown - time format now depends on theme settings
* [tweak] Event Scoreboard and Event Logos tweaks
* [tweak] Featured Player - check for empty vars
* [tweak] Game Results check for an empty stats
* [fix] Event Logos Inline & Blocks markup
* [update] Translation file

= 1.0.3 =
* [tweak] Recent Comment widget now display only approved comments
* [fix] Recent Comments widget date/time bug
* [fix] Incorrect meta for posts in [VC] Posts Carousel
* [fix] Added Comment Icon in [VC] Post Carousel
* [fix] Tags, Hero Unit and Featured Posts buttons custom color issue
* [fix] Widget / Event Blocks arrow position for second command on mobile devices

= 1.0.2 =
* [tweak] Added options to change icons in the Header
* [tweak] Added new color options for body, header, footer
* [tweak] Added option for Page Heading to on/off last word highlight
* [tweak] Events Block Team name width
* [fix] Default Logo path for Header on mobile devices
* [fix] Circular bars colors now changing with Primary Color
* [update] Translation file

= 1.0.1 =
* [tweak] Added icon to VC Newslog Item
* [tweak] Home Sidebars now exist by default
* [fix] Links for nav menu in sample data files
* [fix] Box border custom color for Game > Recap box
* [fix] Demo Import
* [fix] Pushy Panel default logo path
* [fix] SCSS compiler issue on nginx servers
* [update] Translation file

= 1.0.0 =
* Initial release
