<?php
// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

// BEGIN ENQUEUE PARENT ACTION
// AUTO GENERATED - Do not modify or remove comment markers above or below:

add_action('wp_enqueue_scripts', 'dotdigital_child_css', 10);

// Load CSS
function dotdigital_child_css() {
	//dotdigital child theme styles
	wp_deregister_style( 'dotdigital-child-style' );
	wp_register_style( 'dotdigital-child-style', get_parent_theme_file_path() . '/style.css' );
	wp_enqueue_style( 'dotdigital-child-style' );
}

// END ENQUEUE PARENT ACTION
